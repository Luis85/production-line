# Orchestrator CLI and HTTP contract — starter v0.1

Single-line HTTP base: `http://127.0.0.1:3000`; the Factory demo uses
Alpha `:3001` and Beta `:3002`. Factory has its own [API](factory.md#factory-api-contract). JSON request bodies are limited to 64 KiB.
Use `Content-Type: application/json`. Errors are `{ "error": "description" }`.
Unknown task/registration/claim/lease fields and invalid providers are rejected.
Manual intake requires acceptance criteria; requirement-reference intake may
leave them empty for later context resolution. CLI commands reject unrelated flags; an
unknown option does not silently fall back to a mutating default.

Authentication is `Authorization: Bearer TOKEN`. Development admin and enrollment
tokens must be distinct and at least 24 characters. Worker registration returns
a separate opaque token that is stored locally and hashed in SQLite. Project
binding comes from the server's enrollment grant, never the worker request.

| Method / endpoint | Auth | Result / semantics |
| --- | --- | --- |
| `GET /`, `/intake` | Public shell | Intake first; data/actions require admin token |
| `GET /concept` | Public | Separate simulated 3D concept prototype |
| `GET /healthz` | Public | Process health, mock mode, DB schema version |
| `POST /v1/tasks` | Admin | Validate and enqueue; `Idempotency-Key` required |
| `GET /v1/tasks` | Admin | `{tasks: [...]}` |
| `GET /v1/tasks/:id` | Admin | One task or 404 |
| `GET /v1/tasks/:id/events` | Admin | Ordered, task-scoped event history |
| `GET /v1/overview` | Admin | Line task/worker/snapshot counters consumed by Factory; unknown cost stays null |
| `GET /v1/workers` | Admin | Project, profiles, configuration, last contact; no credentials |
| `GET /v1/snapshots` | Admin | Snapshot payloads, digests, receipt times and next cursor |
| `POST /v1/workers/register` | Enrollment | `{profiles,policy}` → worker ID/token/project |
| `GET /v1/worker/assignments/current` | Worker | Current assigned running tasks |
| `POST /v1/worker/assignments/next` | Worker | `{requestId}` → `{task: Task|null}`; atomic claim |
| `POST /v1/worker/tasks/:id/heartbeat` | Worker | `{lease,attempt}` → task with renewed expiry |
| `POST /v1/worker/tasks/:id/complete` | Worker | Same identity; requires snapshot pair and simulated outcome |
| `POST /v1/worker/tasks/:id/abandon` | Worker | Same identity; queues retry or blocks at attempt limit |
| `POST /v1/worker/snapshots` | Worker | Snapshot → `{id,sha256}`; immutable/idempotent |

Claims use a stable request ID across network retries; choose a new ID when asking
for another slot. A replay returns that same still-active assignment, never a
second task. Concurrency counts all active tasks and profile sessions. TTL is
60 seconds; workers renew according to the assigned lease lifetime, including
while terminal snapshots and completion are being acknowledged. Server time is
authoritative.
Expired/superseded lease operations return 409. Replaying successful completion
does not create another finish event. A delayed old snapshot can be indexed as
historical telemetry but cannot complete or publish the task.

Snapshot filters: `project`, `worker`, `task`; `limit` is 1–1000 (default 500).
The default `order=asc` uses `after` (sequence cursor, default 0) for incremental
export. `order=desc` starts with the latest records and uses `before` for older
pages. Do not mix `after` and `before`. Continue with `nextCursor` in the selected
direction while `hasMore` is true. A cursor is a persistent sequence, not a
timestamp; worker capture time and server receipt time are separate fields.

The CLI accepts the equivalent `snapshots list --order desc --before CURSOR`.
A background sweep reconciles expired leases even when no new workers claim
work. The maximum attempt count is pinned for the current assignment and is
not retroactively changed with worker configuration. A later assignment may use
another worker's policy; a task-global immutable retry budget is not implemented.

## Requirement-reference intake

```json
{"project":"demo","requirementRef":"[[Features/Customer portal]]"}
```

`requirementRef` is one validated vault wikilink. Provider and priority are
optional (`auto`, `1`). The server derives a display title when absent, preserves
the reference in the task/context links and does not invent acceptance criteria.
The resolved note, content hash and Git commit are **not** implied by this input.
The mock starter stores an unresolved reference; a future real worker must
resolve and pin that context before code delivery.

CLI shorthand: `task create --project demo --wikilink "[[Features/Customer portal]]"
--key portal-001`. Or `task create --file examples/vault-task.json --key portal-001`.
Use one form per command; `--file -` still reads a single JSON object from stdin.

## Task input

```json
{
  "project": "demo",
  "title": "Export an order as PDF",
  "criteria": ["The export includes every order line"],
  "wikilinks": ["[[specs/Order export#Rules]]"],
  "provider": "auto",
  "priority": 1
}
```

`provider`: `auto`, `claude` or `codex`. `priority`: 1 or 2. Manual `criteria`:
1–30 nonempty strings; with `requirementRef`, 0–30. `wikilinks`: up to 12 explicit links. In the starter references
are syntax-checked/stored, not resolved against the real vault. Repo imports add
`source` with feature ID, iteration ID, branch, commit, note path, specification
hash and iteration PR URL. No revision/patch API is implemented yet.

```bash
curl --fail-with-body http://127.0.0.1:3000/v1/tasks \
  -H "Authorization: Bearer $WERK_ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: order-export-001' \
  --data-binary @examples/task.json
```

The equivalent CLI command is `werk-orchestrator task create --file
examples/task.json --key order-export-001`. `--file -` reads stdin. `--url`
overrides `WERK_URL`; all other behavior uses the same HTTP service.

## Worker status service

Each worker separately serves `GET /` (live HTML), `GET /status` (JSON) and
`GET /healthz` (process status). It is read-only, loopback-only by default and
contains no credentials, prompt text or source code. A healthy HTTP process
may still report `disconnected`; healthcheck success is not a claim that its
provider or server connection is healthy. CLI `werk-worker status --format html`
exports a standalone, non-updating HTML snapshot.

## Client contract and ownership

The same `/v1` commands serve webview and headless CLI clients. `task create
--file - --key STABLE_KEY` accepts one JSON object from stdin, then calls HTTP;
it never opens SQLite. Keep the key/payload unchanged when retrying an uncertain
submission. A timeout can occur after the server commits, so it is not evidence
that the task was rejected. Successful responses, event records and task reads
provide the authoritative result.

Task transition authority stays with the server. A snapshot acknowledgment only
confirms immutable evidence ingestion. Historical telemetry may be stored after
a lease expires, while completion with that lease is rejected. The worker's
status page is local operational state; the orchestrator taskboard is persisted
portfolio state. Neither endpoint is a replacement for the other.

The shared transport rejects credential-bearing URLs and cross-origin API paths,
does not follow redirects, bounds response size and uses a request timeout.
Protocol DTO types document responses for TypeScript clients; `request<T>` is
not automatic runtime schema validation of an untrusted server. HTTP adapters
map semantic application failures to status codes; CLI adapters map them to
nonzero exit codes. See the [architecture ADR](adr-001-client-server-boundaries.md)
for replay, failure and clock boundaries.

## MCP and command selection

`werk-orchestrator overview` reads `/v1/overview`; `health` reads process health.
`mcp serve [--url URL] [--allow-writes true|false]` exposes this one configured
line through stdio, read-only by default. The Factory CLI offers a separate MCP
bridge for its registry. See [Docker Agent integration](docker-agent.md) for
client YAML, credentials, protocol scope and explicit write enablement.

CLI clients do not accept a SQL file or arbitrary operation path. `--url` changes
the service, not the authority of the selected token. One line's admin credential
does not authorize another line. Commands produce JSON on stdout and diagnostics
on stderr (MCP stdout is protocol-only). Exit codes are 0 success, 2 input/API 4xx
or an import revision decision, and 1 operational/network failure.

## Target extensions, not implemented endpoints

Real context resolution, project/user authorization, task revision/cancellation,
drain/hot configuration, publication outbox, Git webhook verification, review
feedback and merge transitions will extend this versioned API. The concept
prototype shows those target behaviors; the starter never fabricates PR events.
