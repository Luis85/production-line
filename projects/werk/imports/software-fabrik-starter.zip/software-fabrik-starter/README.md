# Werk — software factory starter

Three independently deployable Node.js 24 / TypeScript CLI applications:
**Factory** manages the portfolio hierarchy and registered lines; each
**orchestrator** owns one line's Intake-first taskboard and SQLite state;
**workers** execute project-bound mock attempts and expose local HTML status.
The applications share contracts from `src/shared`.

**This is an executable mock foundation.** Tasks can be imported, scheduled,
executed as mock runs and measured. Claude/Codex execution, Git push, real PRs,
review feedback and merge monitoring are not connected. A mock run ends as
`simulated`, never `done`. Unknown cost, token and quality measurements stay null.

For transfer into a development project, start with **[HANDOFF.md](HANDOFF.md)**:
verified scope, setup, technical contracts, prioritized implementation slices,
acceptance gates and a ready-to-use coding-agent prompt.

## Start Factory with two independent lines

Prerequisites: Node **24.x** and npm; Git is needed for repository import.

```text
npm ci
npm run build
npm run dev:factory
```

Open **http://127.0.0.1:3100/**. Use `WERK_FACTORY_ADMIN_TOKEN` from
`.state/factory-fleet/credentials.json`. The launcher creates a demo factory,
Alpha/Beta line registrations, two isolated orchestrators on ports 3001/3002 and
one worker per line. It reuses configuration and secrets and never overwrites
existing line settings. `-- --workers 2` starts two workers per line.

Open Alpha or Beta from Factory to enter its Intake. Use `WERK_LINE_ALPHA_TOKEN`
or `WERK_LINE_BETA_TOKEN` from the same credentials file on that line's login
form. The Factory token is separate and is not forwarded to the new tab.

Factory provides hierarchy and rollups; task intake stays inside a line.
Read [Factory setup](docs/factory.md) for CLI use, Docker hierarchy, credentials
and persistent state. The independent single-line setup below remains available.

## Run one line without Factory

Install Node **24.x** and npm. Git is needed only for iteration import.

```bash
npm ci
npm run build
npm run dev:fleet -- --workers 3
```

Open **http://127.0.0.1:3000/**. Enter `WERK_ADMIN_TOKEN` from
`.state/fleet/credentials.json`; the webview keeps it in page memory. Worker
status views are at **http://127.0.0.1:4101/** through **4103**. Ctrl+C stops
workers before the server, allowing snapshots to flush. The fleet retains data,
credentials and worker identities across clean restarts.

In a second terminal at this project root, load the generated client environment:

```bash
# Bash / compatible shells
source .state/fleet/env.sh
```

```powershell
# PowerShell
. ./.state/fleet/env.ps1
```

Then submit and inspect your first mock task (same commands in either shell):

```text
node src/orchestrator/dist/orchestrator/cli.js task create --project demo --wikilink "[[Features/Customer portal]]" --key first-feature-001
node src/orchestrator/dist/orchestrator/cli.js task list
node src/orchestrator/dist/orchestrator/cli.js workers list
```

The requirement note is the input: you do not need to copy its title and criteria
into intake. The mock runtime preserves the reference unresolved. Real delivery
must resolve and pin its repository context before implementation.

Use `WERK_DEV_PORT` and `WERK_STATUS_BASE` to choose other ports **before starting
the fleet**. The generated environment includes the matching `WERK_URL`.
Existing listeners, overlapping ports and a second launcher on the same state
are rejected. See [operations](docs/operations.md) for crash recovery.

## Run one line with Docker

```text
node scripts/init-env.mjs
docker compose up --build -d --scale worker=3
docker compose port --index 1 worker 4100
docker compose logs -f
docker compose stop
docker compose start
```

For Factory plus two Docker lines, use the [hierarchy overlay](docs/factory.md#docker-hierarchy-example).
The single-line server above uses loopback port 3000; scaled workers receive distinct dynamic
loopback ports and separate state volumes. Read the [operations guide](docs/operations.md)
before changing volumes or running a persistent fleet. Docker execution has not
been validated in this environment.

## Project and interfaces

| Project | Owns | Independent distribution |
| --- | --- | --- |
| `src/factory` | Hierarchy, line registry, portfolio rollups, own SQLite | `src/factory/dist` |
| `src/orchestrator` | API, CLI, Intake/dashboard, SQLite, importer | `src/orchestrator/dist` |
| `src/worker` | CLI, polling, mock execution, journal, HTML status | `src/worker/dist` |
| `src/shared` | Contracts, validation, transport | Included in all three distributions |

```text
npm run build --workspace @werk/factory
npm run build --workspace @werk/orchestrator
npm run build --workspace @werk/worker
node src/factory/dist/factory/cli.js --help
node src/orchestrator/dist/orchestrator/cli.js --help
node src/worker/dist/worker/cli.js --help
npm run typecheck
npm test
```

Each complete `dist` folder can be relocated to another machine with Node 24;
it does not depend on another application's source. Build output replaces stale
files and includes CLI metadata and runtime dependencies. Type stripping is not
a typecheck: run both validation commands before releasing a change.

## Docker Agent

[Docker Agent integration](docs/docker-agent.md) provides subscription-CLI
harness templates for Claude/Codex and native operations-agent configurations
using read-only Werk MCP tools. This is separate from container deployment and
does not yet connect the mock worker to live coding/PR execution.

## Next steps

- [Development guide](docs/development.md): headless stdin intake, iteration import,
  worker concurrency/system prompts, repository artifacts and examples.
- [CLI/API reference](docs/api.md): authentication, payloads, leases and pagination.
- [Architecture decision](docs/adr-001-client-server-boundaries.md): application
  boundaries, state ownership, retries and lease fencing.
- [UI journey](docs/ui-journey.md): Intake, task inspection, worker evidence and
  portfolio interpretation with shared spacing rules.
- [Architecture](docs/architecture.md): weekly Obsidian planning, feature draft PRs,
  human review/rework, merge completion and live-integration gaps.
- [Snapshot semantics](docs/snapshots.md): provenance, cost/quality coverage and
  interpreting time series without false precision.
- [Operations](docs/operations.md): Docker, state, backup/restore and recovery.
- [Review and validation](docs/review-and-validation.md): resolved findings,
  integration test results and remaining verification limits.

Each orchestrator's `/concept` route contains the separate interactive target-design simulation.
Its local browser state is intentionally separate from the live mock taskboard.
