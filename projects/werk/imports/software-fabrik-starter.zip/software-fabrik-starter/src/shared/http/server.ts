import type { IncomingMessage, ServerResponse } from 'node:http';
import { ApiError } from './errors.js';
const INPUT_LIMIT = 65536;
export async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
    if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] ?? ''))
        throw new ApiError(415, 'Content-Type must be application/json');
    const chunks: Buffer[] = [];
    let size = 0;
    for await (const chunk of req) {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        size += buffer.length;
        if (size > INPUT_LIMIT)
            throw new ApiError(413, 'Body limit: 64 KiB');
        chunks.push(buffer);
    }
    let data: unknown;
    try {
        data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    }
    catch {
        throw new ApiError(400, 'Invalid JSON');
    }
    if (!data || typeof data !== 'object' || Array.isArray(data))
        throw new ApiError(400, 'Expected JSON object');
    return data as Record<string, unknown>;
}
export function json(res: ServerResponse, status: number, value: unknown) {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    res.end(JSON.stringify(value));
}
export function html(res: ServerResponse, body: string) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'content-security-policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'" });
    res.end(body);
}
