export type Provider = 'auto' | 'claude' | 'codex';
export interface TaskInput {
    project: string;
    /** Display title; reference-only intake derives this without resolving content. */
    title: string;
    /** Vault-relative requirement note. Presence does not assert resolution or readiness. */
    requirementRef?: string;
    criteria: string[];
    wikilinks: string[];
    provider: Provider;
    priority: number;
    source?: {
        featureId: string;
        iterationId: string;
        branch: string;
        commit: string;
        path: string;
        iterationPrUrl: string;
        specSha256: string;
    };
}
export interface Task extends TaskInput {
    id: string;
    status: 'queued' | 'running' | 'simulated' | 'blocked';
    attempt: number;
    workerId: string | null;
    lease: string | null;
    expiresAt: number | null;
    createdAt: number;
    profile: string | null;
}
export interface Profile {
    id: string;
    provider: 'claude' | 'codex';
    mode: 'mock';
    maxParallel?: number;
}
export interface WorkerPolicy {
    maxParallel: number;
    order: 'priority' | 'fifo';
    maxAttempts: number;
    configHash: string;
}
export interface Adapter {
    readonly mode: 'mock' | 'cli';
    run(task: Task, signal: AbortSignal): Promise<{
        kind: 'simulated' | 'change-set';
        summary: string;
    }>;
}
