import type { Profile, Task, WorkerPolicy } from './domain.js';
import type { Snapshot } from './snapshots.js';
/** Authenticated worker data. Credentials are never included in public summaries. */
export interface WorkerRecord {
    id: string;
    project: string;
    profiles: Profile[];
    seen: number;
    config: WorkerPolicy;
}
export interface WorkerSummary extends WorkerRecord {
    online: boolean;
}
export interface TaskEvent {
    seq: number;
    kind: string;
    at: number;
    detail: unknown;
}
export interface SnapshotRecord {
    seq: number;
    snapshot: Snapshot;
    sha256: string;
    receivedAt: string;
}
export interface SnapshotAcknowledgement {
    id: string;
    sha256: string;
}
export interface SnapshotQuery {
    project?: string;
    worker?: string;
    task?: string;
    after?: number;
    before?: number;
    order?: 'asc' | 'desc';
    limit?: number;
}
export interface RegistrationRequest {
    profiles: Profile[];
    policy?: WorkerPolicy;
}
export interface RegistrationResponse {
    id: string;
    token: string;
    project: string;
}
export interface ClaimRequest {
    requestId: string;
}
export interface ClaimResponse {
    task: Task | null;
}
export interface LeaseRequest {
    lease: string;
    attempt: number;
}
export interface TaskListResponse {
    tasks: Task[];
}
export interface WorkerListResponse {
    workers: WorkerSummary[];
}
export interface TaskEventsResponse {
    events: TaskEvent[];
}
export interface SnapshotListResponse {
    snapshots: SnapshotRecord[];
    nextCursor: number | null;
    hasMore: boolean;
}
export interface HealthResponse {
    ok: boolean;
    mode: 'mock';
    schema: number;
}
export interface ErrorResponse {
    error: string;
}
