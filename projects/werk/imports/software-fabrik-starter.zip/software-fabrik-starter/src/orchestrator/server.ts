import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { identifier } from '../shared/contracts.js';
import { DomainError } from '../shared/errors.js';
import { SCHEMA_VERSION } from './schema.js';
import { Store } from './store.js';
import { OrchestratorApplication } from './application.js';
import { createHttpHandler, tokenAuthorization } from './http.js';

export interface ServerConfig {
  db: string;
  host: string;
  port: number;
  adminToken: string;
  enrollmentToken: string;
  project: string;
  leaseMs?: number;
}

/** Composition root: constructs adapters, owns listening and releases every resource. */
export async function startServer(config: ServerConfig) {
  if (config.adminToken.length < 24 || config.enrollmentToken.length < 24 || config.adminToken === config.enrollmentToken) {
    throw new DomainError('invalid_input', 'Set distinct WERK_ADMIN_TOKEN and WERK_ENROLLMENT_TOKEN, each at least 24 characters');
  }
  identifier(config.project, 'project');
  if (!Number.isInteger(config.port) || config.port < 0 || config.port > 65535) {
    throw new DomainError('invalid_input', 'port: integer 0–65535');
  }
  const [intake, concept] = await Promise.all(
    ['index.html', 'concept.html'].map(file => readFile(new URL('./public/' + file, import.meta.url), 'utf8')),
  );
  const store = new Store(config.db, config.leaseMs);
  const application = new OrchestratorApplication(store, config.project);
  const server = createServer(createHttpHandler({
    application,
    schemaVersion: SCHEMA_VERSION,
    authorize: tokenAuthorization(config.adminToken, config.enrollmentToken),
    views: { intake, concept },
    reportError: error => console.error(error),
  }));
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  try {
    await new Promise<void>((resolve, reject) => {
      const failed = (error: Error) => reject(error);
      server.once('error', failed);
      server.listen(config.port, config.host, () => {
        server.off('error', failed);
        resolve();
      });
    });
  } catch (error) {
    store.close();
    throw error;
  }

  const reaper = setInterval(() => {
    try { store.reapExpired(); }
    catch (error) {
      console.error(JSON.stringify({ event: 'lease_reaper_error', error: error instanceof Error ? error.message : String(error) }));
    }
  }, Math.max(10, Math.min(1000, store.ttl))).unref();

  let closing: Promise<void> | undefined;
  return {
    server,
    store,
    close: () => {
      if (closing) return closing;
      clearInterval(reaper);
      closing = new Promise<void>((resolve, reject) => {
        server.close(error => {
          store.close();
          error ? reject(error) : resolve();
        });
        server.closeIdleConnections();
      });
      return closing;
    },
  };
}
