import type { IncomingMessage, ServerResponse } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { DomainError } from '../shared/errors.js';
import { ApiError, httpStatus } from '../shared/http/errors.js';
import { json, html, readJson } from '../shared/http/server.js';
import type { OrchestratorApplication, WorkerAction } from './application.js';
import type { SnapshotQuery } from '../shared/protocol.js';

export interface HttpDependencies {
  application: OrchestratorApplication;
  schemaVersion: number;
  authorize(token: string, role: 'admin' | 'enrollment'): void;
  views: { intake: string; concept: string };
  reportError(error: unknown): void;
}

/** Constant-time verification lives in the transport boundary, not persistence. */
export function tokenAuthorization(adminToken: string, enrollmentToken: string): HttpDependencies['authorize'] {
  return (token, role) => {
    const actual = Buffer.from(token);
    const expected = Buffer.from(role === 'admin' ? adminToken : enrollmentToken);
    if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
      throw new ApiError(401, role === 'admin' ? 'Admin token required' : 'Invalid enrollment token');
    }
  };
}

function snapshotQuery(parameters: URLSearchParams): SnapshotQuery {
  const number = (key: string) => parameters.has(key) ? Number(parameters.get(key)) : undefined;
  return {
    project: parameters.get('project') ?? undefined,
    worker: parameters.get('worker') ?? undefined,
    task: parameters.get('task') ?? undefined,
    after: number('after'),
    before: number('before'),
    order: (parameters.get('order') ?? 'asc') as SnapshotQuery['order'],
    limit: number('limit'),
  };
}

/** HTTP adapts credentials, request bytes and status codes to application operations. */
export function createHttpHandler(dependencies: HttpDependencies) {
  const { application, authorize, views, reportError } = dependencies;
  return async (request: IncomingMessage, response: ServerResponse): Promise<void> => {
    try {
      const target = new URL(request.url ?? '/', 'http://localhost');
      const path = target.pathname;
      const method = request.method;
      if (method === 'GET' && path === '/healthz') {
        return json(response, 200, { ok: true, mode: 'mock', schema: dependencies.schemaVersion });
      }
      if (method === 'GET' && (path === '/' || path === '/intake')) return html(response, views.intake);
      if (method === 'GET' && path === '/concept') return html(response, views.concept);

      const token = (request.headers.authorization ?? '').replace(/^Bearer /, '');
      if (method === 'POST' && path === '/v1/workers/register') {
        authorize(token, 'enrollment');
        return json(response, 201, application.register(await readJson(request)));
      }

      if (path.startsWith('/v1/worker/')) {
        const worker = application.worker(token);
        if (method === 'GET' && path === '/v1/worker/assignments/current') {
          return json(response, 200, worker.current());
        }
        if (method === 'POST' && path === '/v1/worker/assignments/next') {
          return json(response, 200, worker.claim(await readJson(request)));
        }
        if (method === 'POST' && path === '/v1/worker/snapshots') {
          return json(response, 201, worker.snapshot(await readJson(request)));
        }
        const match = path.match(/^\/v1\/worker\/tasks\/([^/]+)\/(heartbeat|complete|abandon)$/);
        if (method === 'POST' && match) {
          return json(response, 200, worker.execute(match[2] as WorkerAction, match[1], await readJson(request)));
        }
        throw new ApiError(404, 'Unknown worker endpoint');
      }

      authorize(token, 'admin');
      if (method === 'POST' && path === '/v1/tasks') {
        const key = String(request.headers['idempotency-key'] ?? '');
        return json(response, 201, application.createTask(await readJson(request), key));
      }
      if (method === 'GET' && path === '/v1/overview') return json(response, 200, application.overview());
      if (method === 'GET' && path === '/v1/tasks') return json(response, 200, application.tasks());
      if (method === 'GET' && path === '/v1/workers') return json(response, 200, application.workers());
      if (method === 'GET' && path === '/v1/snapshots') {
        return json(response, 200, application.snapshots(snapshotQuery(target.searchParams)));
      }
      const match = path.match(/^\/v1\/tasks\/([^/]+)(\/events)?$/);
      if (method === 'GET' && match) {
        return json(response, 200, match[2] ? application.taskEvents(match[1]) : application.task(match[1]));
      }
      throw new ApiError(404, 'Unknown API endpoint');
    } catch (error) {
      const expected = error instanceof DomainError || error instanceof ApiError;
      json(response, httpStatus(error), { error: expected ? error.message : 'Internal server error' });
      if (!expected) reportError(error);
    }
  };
}
