import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { identifier } from '../shared/contracts.js';
import { DomainError } from '../shared/errors.js';
import { ApiError } from '../shared/http/errors.js';
import { request } from '../shared/http/client.js';
import type { Task } from '../shared/contracts.js';
import type { TaskListResponse } from '../shared/protocol.js';
import { collectIteration, submitIteration } from './iteration.js';
import type { IterationSource, IterationTaskGateway } from './iteration.js';

const exec = promisify(execFile);

async function gitSource(repo: string, branch: string): Promise<IterationSource> {
  const git = async (...args: string[]) => {
    try { return (await exec('git', ['-C', repo, ...args], { maxBuffer: 4 * 1024 * 1024, timeout: 10000 })).stdout; }
    catch (error) {
      throw new DomainError('invalid_input', `Cannot read iteration repository (${args[0]}): ${error instanceof Error ? error.message : String(error)}`);
    }
  };
  if (branch.startsWith('-') || branch.includes('@{')) throw new DomainError('invalid_input', '--branch must name a local branch');
  await git('check-ref-format', 'refs/heads/' + branch);
  const commit = (await git('rev-parse', '--verify', '--end-of-options', 'refs/heads/' + branch + '^{commit}')).trim();
  return {
    commit,
    files: async folder => (await git('ls-tree', '-rz', '--name-only', commit, '--', ':(literal)' + folder)).split('\0').filter(path => path.endsWith('.md')),
    read: path => git('show', commit + ':' + path),
  };
}

function taskGateway(base: string, token: string): IterationTaskGateway {
  return {
    listTasks: async () => (await request<TaskListResponse>(base, '/v1/tasks', token)).tasks,
    createTask: async (input, key) => {
      try { return await request<Task>(base, '/v1/tasks', token, 'POST', input, key); }
      catch (error) {
        if (error instanceof ApiError && error.status === 409) throw new DomainError('conflict', error.message);
        throw error;
      }
    },
  };
}

/** CLI composition boundary for local Git and remote task API adapters. */
export async function importIteration(options: Record<string, string>, token: string) {
  for (const key of ['repo', 'branch', 'project', 'iteration', 'iteration-pr']) {
    if (!options[key]) throw new DomainError('invalid_input', `--${key} required`);
  }
  if (options['dry-run'] !== undefined && !['true', 'false'].includes(options['dry-run'])) {
    throw new DomainError('invalid_input', '--dry-run must be true or false');
  }
  const project = identifier(options.project, 'project');
  const iteration = identifier(options.iteration, 'iteration');
  const features = options.features ?? 'docs/features';
  if (!features || features.startsWith('/') || features.split('/').some(part => !part || part === '..' || part === '.')
    || features.startsWith(':') || /[\\\x00-\x1f]/.test(features)) {
    throw new DomainError('invalid_input', '--features must be a literal repository-relative folder');
  }
  const source = await gitSource(options.repo, options.branch);
  const plan = await collectIteration(source, {
    project, iteration, branch: options.branch, features, iterationPrUrl: options['iteration-pr'],
  });
  if (options['dry-run'] === 'true') return { mode: 'preview' as const, ...plan };
  const base = options.url ?? process.env.WERK_URL ?? 'http://127.0.0.1:3000';
  return submitIteration(plan, taskGateway(base, token));
}
