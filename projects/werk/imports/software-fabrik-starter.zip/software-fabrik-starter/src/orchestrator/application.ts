import { identifier, object } from '../shared/contracts.js';
import { DomainError } from '../shared/errors.js';
import type { OrchestratorOverview } from '../shared/factory.js';
import type { Task } from '../shared/contracts.js';
import type {
  SnapshotAcknowledgement, SnapshotQuery, SnapshotRecord,
  TaskEvent, WorkerRecord, WorkerSummary,
} from '../shared/protocol.js';

/** Transactional operations required by the application, without SQLite or HTTP types. */
export interface OrchestratorRepository {
  overview(project: string): OrchestratorOverview;
  submit(input: unknown, idempotencyKey: string): Task;
  list(): Task[];
  get(taskId: string): Task;
  events(taskId: string): TaskEvent[];
  register(project: string, profiles: unknown, policy?: unknown): { id: string; token: string };
  worker(token: string): WorkerRecord;
  workers(): WorkerSummary[];
  current(worker: WorkerRecord): Task[];
  claim(worker: WorkerRecord, requestId: string): Task | null;
  heartbeat(worker: WorkerRecord, taskId: string, lease: unknown, attempt: unknown): Task;
  finish(worker: WorkerRecord, taskId: string, lease: unknown, attempt: unknown): Task;
  abandon(worker: WorkerRecord, taskId: string, lease: unknown, attempt: unknown): Task;
  snapshot(worker: WorkerRecord, input: unknown): SnapshotAcknowledgement;
  snapshots(query: SnapshotQuery): SnapshotRecord[];
}

export type WorkerAction = 'heartbeat' | 'complete' | 'abandon';

/** A resolved identity cannot be replaced by a worker ID supplied in a request body. */
export class WorkerOperations {
  private readonly repository: OrchestratorRepository;
  private readonly identity: WorkerRecord;

  constructor(repository: OrchestratorRepository, identity: WorkerRecord) {
    this.repository = repository;
    this.identity = identity;
  }

  current() {
    return { tasks: this.repository.current(this.identity) };
  }

  claim(input: unknown) {
    const body = object(input, 'Assignment request', ['requestId']);
    if (typeof body.requestId !== 'string' || !/^[\w-]{1,100}$/.test(body.requestId)) {
      throw new DomainError('invalid_input', 'requestId required: 1–100 letters, digits, _ or -');
    }
    return { task: this.repository.claim(this.identity, body.requestId) };
  }

  snapshot(input: unknown) {
    return this.repository.snapshot(this.identity, input);
  }

  execute(action: WorkerAction, taskId: string, input: unknown): Task {
    const body = object(input, 'Lease command', ['lease', 'attempt']);
    if (typeof body.lease !== 'string' || !body.lease || !Number.isSafeInteger(body.attempt) || Number(body.attempt) < 1) {
      throw new DomainError('invalid_input', 'lease string and positive integer attempt required');
    }
    switch (action) {
      case 'heartbeat': return this.repository.heartbeat(this.identity, taskId, body.lease, body.attempt);
      case 'complete': return this.repository.finish(this.identity, taskId, body.lease, body.attempt);
      case 'abandon': return this.repository.abandon(this.identity, taskId, body.lease, body.attempt);
    }
  }
}

export class OrchestratorApplication {
  readonly project: string;

  private readonly repository: OrchestratorRepository;

  constructor(repository: OrchestratorRepository, project: string) {
    this.repository = repository;
    this.project = identifier(project, 'project');
  }

  register(input: unknown) {
    const body = object(input, 'Worker registration', ['profiles', 'policy']);
    return { ...this.repository.register(this.project, body.profiles, body.policy), project: this.project };
  }

  worker(token: string): WorkerOperations {
    return new WorkerOperations(this.repository, this.repository.worker(token));
  }

  createTask(input: unknown, idempotencyKey: string): Task {
    return this.repository.submit(input, idempotencyKey);
  }

  overview() { return this.repository.overview(this.project); }
  tasks() { return { tasks: this.repository.list() }; }
  task(taskId: string) { return this.repository.get(taskId); }
  taskEvents(taskId: string) { return { events: this.repository.events(taskId) }; }
  workers() { return { workers: this.repository.workers() }; }

  snapshots(query: SnapshotQuery = {}) {
    const order = query.order ?? 'asc';
    const limit = query.limit ?? 500;
    if (!['asc', 'desc'].includes(order) || !Number.isInteger(limit) || limit < 1 || limit > 1000) {
      throw new DomainError('invalid_input', 'order asc|desc; limit 1–1000');
    }
    if ((order === 'desc' && query.after !== undefined) || (order === 'asc' && query.before !== undefined)) {
      throw new DomainError('invalid_input', 'Use after with ascending order or before with descending order');
    }
    for (const cursor of [query.before, query.after]) {
      if (cursor !== undefined && (!Number.isSafeInteger(cursor) || cursor < 0)) {
        throw new DomainError('invalid_input', 'Snapshot cursor must be nonnegative');
      }
    }
    const page = this.repository.snapshots({ ...query, order, limit: limit + 1 });
    const snapshots = page.slice(0, limit);
    return {
      snapshots,
      nextCursor: snapshots.at(-1)?.seq ?? (order === 'asc' ? (query.after ?? 0) : (query.before ?? null)),
      hasMore: page.length > limit,
    };
  }
}
