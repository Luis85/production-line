import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { DomainError } from '../shared/errors.js';
import { LINE_TOKEN_PATTERN } from '../shared/factory.js';
import { SqliteFactoryRegistry } from './registry.js';
import { FactoryApplication } from './application.js';
import { HttpLineReader } from './poller.js';
import { createFactoryHandler } from './http.js';
export interface FactoryServerConfig {
    db: string;
    host: string;
    port: number;
    adminToken: string;
    credentials?: Record<string, string | undefined>;
    pollTimeoutMs?: number;
    pollConcurrency?: number;
}
export async function startFactoryServer(config: FactoryServerConfig) {
    if (typeof config.adminToken !== 'string' || config.adminToken.length < 24)
        throw new DomainError('invalid_input', 'Set WERK_FACTORY_ADMIN_TOKEN to at least 24 characters');
    if (!Number.isInteger(config.port) || config.port < 0 || config.port > 65535)
        throw new DomainError('invalid_input', 'port: integer 0–65535');
    const timeout = config.pollTimeoutMs ?? 3000, concurrency = config.pollConcurrency ?? 4;
    if (!Number.isInteger(timeout) || timeout < 50 || timeout > 30000 || !Number.isInteger(concurrency) || concurrency < 1 || concurrency > 16)
        throw new DomainError('invalid_input', 'Polling timeout 50–30000 ms and concurrency 1–16 required');
    const credentials: Record<string, string> = {};
    for (const [name, value] of Object.entries(config.credentials ?? process.env))
        if (LINE_TOKEN_PATTERN.test(name) && value) {
            if (value === config.adminToken)
                throw new DomainError('invalid_input', 'Factory admin and production line credentials must be distinct');
            credentials[name] = value;
        }
    const view = await readFile(new URL('./public/index.html', import.meta.url), 'utf8');
    const registry = new SqliteFactoryRegistry(config.db), reader = new HttpLineReader(credentials, timeout, concurrency);
    const application = new FactoryApplication(registry, reader, new Set(Object.keys(credentials)));
    const server = createServer(createFactoryHandler(application, config.adminToken, view, error => console.error(error)));
    server.requestTimeout = 15000;
    server.headersTimeout = 10000;
    try {
        await new Promise<void>((resolve, reject) => { const failed = (error: Error) => reject(error); server.once('error', failed); server.listen(config.port, config.host, () => { server.off('error', failed); resolve(); }); });
    }
    catch (error) {
        reader.close();
        registry.close();
        throw error;
    }
    let closing: Promise<void> | undefined;
    return { server, registry, application, close: () => {
            if (closing)
                return closing;
            reader.close();
            closing = new Promise<void>((resolve, reject) => { server.close(error => { registry.close(); error ? reject(error) : resolve(); }); server.closeIdleConnections(); });
            return closing;
        } };
}
