import type { IncomingMessage, ServerResponse } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { DomainError } from '../shared/errors.js';
import { ApiError, httpStatus, isExpectedError } from '../shared/http/errors.js';
import { json, html, readJson } from '../shared/http/server.js';
import { identifier } from '../shared/contracts.js';
import type { FactoryApplication } from './application.js';
export function createFactoryHandler(application: FactoryApplication, adminToken: string, view: string, reportError: (error: unknown) => void) {
    return async (request: IncomingMessage, response: ServerResponse) => {
        try {
            const target = new URL(request.url ?? '/', 'http://localhost'), path = target.pathname, method = request.method;
            if (method === 'GET' && path === '/healthz')
                return json(response, 200, { ok: true, service: 'factory', schema: 1 });
            if (method === 'GET' && (path === '/' || /^\/factories\/[^/]+$/.test(path)))
                return html(response, view);
            const received = Buffer.from((request.headers.authorization ?? '').replace(/^Bearer /, '')), expected = Buffer.from(adminToken);
            if (received.length !== expected.length || !timingSafeEqual(received, expected))
                throw new ApiError(401, 'Factory admin token required');
            if (method === 'GET' && path === '/v1/overview') {
                const id = target.searchParams.get('factoryId');
                return json(response, 200, await application.overview(id === null ? undefined : identifier(id, 'factoryId')));
            }
            if (path === '/v1/factories') {
                if (method === 'GET')
                    return json(response, 200, application.factories());
                if (method === 'POST')
                    return json(response, 201, application.createFactory(await readJson(request)));
            }
            if (path === '/v1/lines') {
                if (method === 'GET')
                    return json(response, 200, application.lines());
                if (method === 'POST')
                    return json(response, 201, application.createLine(await readJson(request)));
            }
            const match = path.match(/^\/v1\/(factories|lines)\/([^/]+)$/);
            if (match) {
                const id = identifier(match[2], 'id'), factory = match[1] === 'factories';
                if (method === 'GET')
                    return json(response, 200, factory ? application.factory(id) : application.line(id));
                if (method === 'PATCH')
                    return json(response, 200, factory ? application.updateFactory(id, await readJson(request)) : application.updateLine(id, await readJson(request)));
                if (method === 'DELETE')
                    return json(response, 200, factory ? application.deleteFactory(id) : application.deleteLine(id));
            }
            throw new DomainError('not_found', 'Unknown Factory endpoint');
        }
        catch (error) {
            json(response, httpStatus(error), { error: isExpectedError(error) && error instanceof Error ? error.message : 'Internal server error' });
            if (!isExpectedError(error))
                reportError(error);
        }
    };
}
