import { factoryInput, lineInput } from '../shared/factory.js';
import { DomainError } from '../shared/errors.js';
import type { FactoryOverview, LineOverview, ProductionLine } from '../shared/factory.js';
import type { FactoryRegistry, LineReader } from './ports.js';
import { descendantFactories, overviewTotals } from './overview.js';

/** Registry commands and portfolio observation, independent of SQLite and HTTP. */
export class FactoryApplication {
    private readonly registry: FactoryRegistry;
    private readonly reader: LineReader;
    private readonly configuredCredentials: ReadonlySet<string>;
    private readonly now: () => number;

    constructor(registry: FactoryRegistry, reader: LineReader, configuredCredentials: ReadonlySet<string>, now = Date.now) {
        this.registry = registry;
        this.reader = reader;
        this.configuredCredentials = configuredCredentials;
        this.now = now;
    }

    factories() { return { factories: this.registry.factories() }; }
    factory(id: string) { return this.registry.factory(id); }
    createFactory(input: unknown) { return this.registry.createFactory(factoryInput(input)); }
    updateFactory(id: string, input: unknown) {
        return this.registry.updateFactory(id, factoryInput(input, this.registry.factory(id)));
    }
    deleteFactory(id: string) {
        this.registry.deleteFactory(id);
        return { deleted: true, id };
    }

    lines() { return { lines: this.registry.lines() }; }
    line(id: string) { return this.registry.line(id); }
    private requireConfiguredCredential(reference: string): void {
        if (!this.configuredCredentials.has(reference)) {
            throw new DomainError('invalid_input', 'tokenEnv must reference a configured WERK_LINE_<NAME>_TOKEN credential');
        }
    }
    createLine(input: unknown) {
        const value = lineInput(input);
        this.requireConfiguredCredential(value.tokenEnv);
        return this.registry.createLine(value);
    }
    updateLine(id: string, input: unknown) {
        const previous = this.registry.line(id);
        const value = lineInput(input, previous);
        // Missing deployment credentials must not prevent renaming or moving an existing registration.
        if (value.tokenEnv !== previous.tokenEnv) this.requireConfiguredCredential(value.tokenEnv);
        return this.registry.updateLine(id, value);
    }
    deleteLine(id: string) {
        this.registry.deleteLine(id);
        return { deleted: true, id };
    }

    private async observe(line: ProductionLine): Promise<LineOverview> {
        try {
            return await this.reader.read(line);
        } catch {
            // One failed integration cannot erase healthy lines or reflect adapter/credential diagnostics.
            return {
                line, status: 'unavailable', checkedAt: new Date(this.now()).toISOString(),
                error: 'Unable to read this production line; other lines remain available', overview: null,
            };
        }
    }

    async overview(factoryId?: string): Promise<FactoryOverview> {
        if (factoryId !== undefined) this.registry.factory(factoryId);
        const factories = descendantFactories(this.registry.factories(), factoryId);
        const scope = new Set(factories.map(factory => factory.id));
        const registered = this.registry.lines().filter(line => scope.has(line.factoryId));
        const lines = await Promise.all(registered.map(line => this.observe(line)));
        return {
            factoryId: factoryId ?? null,
            observedAt: new Date(this.now()).toISOString(),
            factories,
            lines,
            totals: overviewTotals(lines),
        };
    }
}
