import { randomUUID } from 'node:crypto';
import { loadavg } from 'node:os';
import { performance, monitorEventLoopDelay } from 'node:perf_hooks';
import { mkdir, readFile, readdir, unlink, access, lstat } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import type { Task, Profile } from '../shared/contracts.js';
import { validateSnapshot, type Snapshot } from '../shared/snapshots.js';
import { atomicWrite } from './files.js';
import type { SnapshotStatus } from './application/ports.js';
const processInstanceId = randomUUID();
export class SnapshotJournal {
    stateDir: string;
    projectDir?: string;
    configHash: string;
    promptHash: string;
    settings: Record<string, unknown>;
    histogram = monitorEventLoopDelay({ resolution: 20 });
    started = new Map<string, number>();
    private writes = Promise.resolve();
    private flushing = Promise.resolve();
    constructor(stateDir: string, configHash: string, promptHash: string, projectDir?: string, settings: Record<string, unknown> = {}) { this.settings = settings; this.stateDir = stateDir; this.projectDir = projectDir; this.configHash = configHash; this.promptHash = promptHash; this.histogram.enable(); }
    close() { this.histogram.disable(); }
    async init() {
        await mkdir(join(this.stateDir, 'outbox'), { recursive: true, mode: 0o700 });
        if (this.projectDir)
            await access(join(resolve(this.projectDir), '.git')).catch(() => { throw Error('--project-dir must be the root of an existing Git checkout'); });
    }
    capture(task: Task, workerId: string, profile: Profile, status: SnapshotStatus, phase: 'before' | 'after', before?: Snapshot, outcome: Snapshot['execution']['outcome'] = 'pending', error: string | null = null, recovered = false): Snapshot {
        const memory = process.memoryUsage(), cpu = process.cpuUsage(), usage = process.resourceUsage();
        const lease = task.lease!;
        if (phase === 'before') {
            this.started.set(lease, performance.now());
        }
        const duration = phase === 'after' && this.started.has(lease) ? performance.now() - this.started.get(lease)! : null;
        if (phase === 'after')
            this.started.delete(lease);
        const sameProcess = before?.runtime.processInstanceId === processInstanceId;
        return { schemaVersion: 1, id: lease + '-' + phase, pairId: lease, phase, capturedAt: new Date().toISOString(), workerId, project: task.project, taskId: task.id, attempt: task.attempt, profileId: profile.id, provider: profile.provider, mode: 'mock',
            configuration: { ...this.settings, profileMaxParallel: profile.maxParallel ?? 1 }, runtime: { processInstanceId, node: process.version, platform: process.platform, arch: process.arch, workerVersion: '0.1.0', adapterVersion: 'mock-1' },
            execution: { outcome, durationMs: duration, timingSource: recovered ? 'unavailable_after_restart' : 'monotonic', error: error ? error.slice(0, 300) : null },
            resources: { scope: 'worker_process', rssBytes: memory.rss, heapUsedBytes: memory.heapUsed, peakRssBytes: usage.maxRSS * 1024, cpuUserMicros: cpu.user, cpuSystemMicros: cpu.system, cpuDeltaMicros: phase === 'after' && sameProcess && !recovered ? Math.max(0, cpu.user + cpu.system - before!.resources.cpuUserMicros - before!.resources.cpuSystemMicros) : null, uptimeSeconds: process.uptime(), hostLoad1m: loadavg()[0] },
            health: { serverLastContactAt: status.lastContact, heartbeatErrors: status.heartbeatErrors, eventLoopDelayP95Ms: phase === 'after' && !recovered ? this.histogram.percentile(95) / 1e6 : null, recoveredAfterCrash: recovered },
            usage: { inputTokens: null, outputTokens: null, cacheReadTokens: null, cacheWriteTokens: null, providerReportedCostUsd: null, estimatedCostUsd: null, subscriptionAllocatedCostUsd: null, subscriptionRemaining: null, source: 'unavailable_mock', reason: 'No provider CLI ran. Subscription cost allocation requires a separate accounting policy.' },
            quality: { build: 'not_run', tests: 'not_run', testsTotal: null, testsPassed: null, coveragePercent: null, lintErrors: null, securityFindings: null, gate: 'not_evaluated' },
            provenance: { iterationId: task.source?.iterationId ?? null, featureId: task.source?.featureId ?? null, sourceCommit: task.source?.commit ?? null, repoBaseCommit: null, testedCommit: null, contextManifestHash: null, skillsVersion: null, policyVersion: 'mock-only-1', configurationHash: this.configHash, systemPromptHash: this.promptHash, artifactPath: `.factory/runs/${task.id}/attempt-${task.attempt}/${lease}/${phase}.json` } };
    }
    path(pairId: string, phase: string) {
        if (!/^[a-zA-Z0-9_-]{1,100}$/.test(pairId) || !['before', 'after'].includes(phase))
            throw Error('Invalid snapshot path');
        return join(this.stateDir, 'snapshots', pairId, phase + '.json');
    }
    async read(pairId: string, phase: string): Promise<Snapshot | null> { try {
        return validateSnapshot(JSON.parse(await readFile(this.path(pairId, phase), 'utf8')));
    }
    catch (e) {
        if ((e as NodeJS.ErrnoException).code === 'ENOENT')
            return null;
        throw e;
    } }
    persist(snapshot: Snapshot): Promise<Snapshot> {
        validateSnapshot(snapshot);
        const pending = this.writes.catch(() => { }).then(() => this.persistOne(snapshot));
        this.writes = pending.then(() => { });
        // A caller handles the returned rejection; the scheduling chain must not leak one.
        this.writes.catch(() => { });
        return pending;
    }
    private async persistOne(snapshot: Snapshot): Promise<Snapshot> {
        const prior = await this.read(snapshot.pairId, snapshot.phase), data = prior ?? snapshot, body = JSON.stringify(data, null, 2) + '\n';
        await mkdir(join(this.stateDir, 'snapshots', data.pairId), { recursive: true, mode: 0o700 });
        if (!prior)
            await atomicWrite(this.path(data.pairId, data.phase), body);
        if (this.projectDir) {
            let parent = resolve(this.projectDir);
            const parts = data.provenance.artifactPath.split('/');
            for (const part of parts.slice(0, -1)) {
                if (!part || part === '..' || part === '.')
                    throw Error('Invalid artifact path');
                parent = join(parent, part);
                await mkdir(parent).catch(e => { if (e.code !== 'EEXIST')
                    throw e; });
                const info = await lstat(parent);
                if (info.isSymbolicLink() || !info.isDirectory())
                    throw Error('Snapshot artifact path must not contain symlinks');
            }
            const path = join(parent, parts.at(-1)!);
            try {
                const info = await lstat(path);
                if (info.isSymbolicLink())
                    throw Error('Snapshot file must not be a symlink');
            }
            catch (e) {
                if ((e as NodeJS.ErrnoException).code !== 'ENOENT')
                    throw e;
            }
            await atomicWrite(path, body, 0o644);
        }
        const queued = join(this.stateDir, 'outbox', data.id + '.json');
        await atomicWrite(queued, body);
        return data;
    }
    flush(send: (data: Snapshot) => Promise<unknown>): Promise<void> {
        const pending = this.flushing.catch(() => { }).then(() => this.flushOne(send));
        this.flushing = pending;
        this.flushing.catch(() => { });
        return pending;
    }
    private async flushOne(send: (data: Snapshot) => Promise<unknown>) {
        await this.writes;
        const files = (await readdir(join(this.stateDir, 'outbox'))).filter(f => f.endsWith('.json'));
        const pending = await Promise.all(files.map(async (file) => ({ file, data: validateSnapshot(JSON.parse(await readFile(join(this.stateDir, 'outbox', file), 'utf8'))) })));
        pending.sort((a, b) => a.data.phase === b.data.phase ? a.data.capturedAt.localeCompare(b.data.capturedAt) : a.data.phase === 'before' ? -1 : 1);
        for (const { file, data } of pending) {
            await send(data);
            await unlink(join(this.stateDir, 'outbox', file));
        }
    }
    async recover(workerId: string, profiles: Profile[], status: SnapshotStatus) {
        let dirs: string[] = [];
        try {
            dirs = await readdir(join(this.stateDir, 'snapshots'));
        }
        catch (e) {
            if ((e as NodeJS.ErrnoException).code !== 'ENOENT')
                throw e;
        }
        for (const pairId of dirs) {
            const before = await this.read(pairId, 'before');
            if (!before)
                continue;
            if (before.workerId !== workerId)
                throw Error('Snapshot journal belongs to another worker');
            const after = await this.read(pairId, 'after');
            await this.persist(before);
            if (after) {
                await this.persist(after);
                continue;
            }
            const task = { id: before.taskId, project: before.project, attempt: before.attempt, lease: pairId } as Task;
            const profile = profiles.find(p => p.id === before.profileId);
            if (!profile)
                throw Error('Snapshot journal references an unavailable profile');
            const recovered = this.capture(task, workerId, profile, status, 'after', before, 'interrupted', 'Worker restarted before recording a terminal snapshot', true);
            recovered.provenance = { ...before.provenance, artifactPath: recovered.provenance.artifactPath };
            recovered.configuration = before.configuration;
            await this.persist(recovered);
        }
    }
}
