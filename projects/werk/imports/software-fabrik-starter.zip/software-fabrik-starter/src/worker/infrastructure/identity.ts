import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { Profile, WorkerPolicy } from '../../shared/contracts.js';
import type { WorkerGateway, WorkerIdentity } from '../application/ports.js';
import { atomicWrite } from '../files.js';

export async function loadOrRegisterIdentity(
  stateDir: string, url: string, profiles: Profile[], policy: WorkerPolicy,
  gateway: WorkerGateway, stop: AbortSignal
): Promise<WorkerIdentity> {
  let identity: WorkerIdentity;
  try {
    identity = JSON.parse(await readFile(join(stateDir, 'identity.json'), 'utf8'));
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    stop.throwIfAborted();
    const registered = await gateway.register(profiles, policy);
    identity = { ...registered, url, configHash: policy.configHash };
    await atomicWrite(join(stateDir, 'identity.json'), JSON.stringify(identity));
  }
  if (identity.url !== url || identity.configHash !== policy.configHash) {
    throw Error('Identity is bound to server and configuration. Drain this worker and use a new state directory for changed configuration.');
  }
  if (![identity.id, identity.token, identity.project].every(value => typeof value === 'string' && value.length > 0)) {
    throw Error('Invalid persisted worker identity');
  }
  return identity;
}
