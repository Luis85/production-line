import { createServer } from 'node:http';
import { html, json } from '../shared/io.js';
import { statusHtml } from './status-view.js';
export { statusHtml } from './status-view.js';
export interface Status {
  workerId: string | null; project: string | null; mode: 'mock'; state: string;
  taskId: string | null; attempt: number | null; profile: string | null;
  completedSimulations: number; lastContact: string | null; lastError: string | null;
  updatedAt: string; profiles: {id:string;provider:string;mode:string}[];
  heartbeatErrors: number; maxParallel: number; activeTasks: {id:string;attempt:number;profile:string|null}[];
  configurationHash: string; lastSnapshot: string|null;
}
export async function statusServer(get: () => Status, host: string, port: number) {
  const server=createServer((req,res) => {
    if(req.method !== 'GET')return json(res,405,{error:'Read-only status service'});
    if(req.url === '/')return html(res,statusHtml());
    if(req.url === '/status' || req.url === '/healthz')return json(res,200,get());
    return json(res,404,{error:'Not found'});
  });
  await new Promise<void>((resolve,reject) => {server.once('error',reject);server.listen(port,host,resolve);});
  return server;
}
