import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { object, profiles, workerPolicy } from '../shared/contracts.js';
import { ValidationError } from '../shared/errors.js';
import { integer } from '../shared/cli.js';

const hash = (value: string) => createHash('sha256').update(value).digest('hex');
const defaultPrompt = 'Implement the assigned feature in the project context. Follow the factory policy and report evidence honestly.';

function section(raw: Record<string, unknown>, key: string, fields: string[]): Record<string, unknown> {
  const value = object(raw[key] === undefined ? {} : raw[key], `${key} configuration`, fields);
  if (Object.values(value).some(item => item === null)) throw new ValidationError(`Invalid ${key} configuration field`);
  return value;
}

/** Normalize external configuration once; the hash pins the effective execution policy. */
export async function configuration(options: Record<string, string>) {
  let parsed: unknown = {};
  if (options.config) {
    const source = await readFile(options.config, 'utf8');
    if (Buffer.byteLength(source) > 65536) throw new ValidationError('Worker configuration limit: 64 KiB');
    try { parsed = JSON.parse(source); }
    catch { throw new ValidationError('Invalid worker configuration JSON'); }
  }
  const raw = object(parsed, 'Worker configuration', ['schemaVersion', 'scheduler', 'execution', 'systemPrompt', 'profiles']);
  if (raw.schemaVersion !== undefined && raw.schemaVersion !== 1) throw new ValidationError('Unknown worker configuration version');
  const scheduler = section(raw, 'scheduler', ['maxParallel', 'order', 'pollMs', 'maxAttempts']);
  const execution = section(raw, 'execution', ['mode', 'timeoutMs', 'mockMs']);
  if (execution.mode !== undefined && execution.mode !== 'mock') throw new ValidationError('Only mock execution is implemented in this starter');
  const systemPrompt = raw.systemPrompt === undefined ? defaultPrompt : raw.systemPrompt;
  if (typeof systemPrompt !== 'string' || !systemPrompt.trim() || systemPrompt.length > 20000) {
    throw new ValidationError('systemPrompt must contain 1–20000 characters');
  }
  const defaults = [
    { id: 'claude-1', provider: 'claude', mode: 'mock' },
    { id: 'codex-2', provider: 'codex', mode: 'mock' }
  ];
  const configuredProfiles = options.profiles
    ? options.profiles.split(',').map((provider, index) => ({ id: `${provider}-${index + 1}`, provider, mode: 'mock' }))
    : raw.profiles === undefined ? defaults : raw.profiles;
  const ps = profiles(configuredProfiles);
  const policy = workerPolicy({
    maxParallel: integer(options.parallel ?? String(scheduler.maxParallel ?? 1), 'parallel', 1, 8),
    order: scheduler.order ?? 'priority', maxAttempts: scheduler.maxAttempts ?? 3, configHash: hash('pending')
  });
  const pollMs = integer(options['poll-ms'] ?? String(scheduler.pollMs ?? 1000), 'poll-ms', 100, 30000);
  const mockMs = integer(options['mock-ms'] ?? String(execution.mockMs ?? 3000), 'mock-ms', 1, 3600000);
  const timeoutMs = integer(options['timeout-ms'] ?? String(execution.timeoutMs ?? 60000), 'timeout-ms', 50, 3600000);
  const normalized = {
    schemaVersion: 1,
    scheduler: { ...policy, configHash: undefined, pollMs },
    execution: { mode: 'mock', mockMs, timeoutMs },
    profiles: ps, systemPrompt
  };
  policy.configHash = hash(JSON.stringify(normalized));
  return { profiles: ps, policy, pollMs, mockMs, timeoutMs, systemPromptHash: hash(systemPrompt), systemPrompt };
}
