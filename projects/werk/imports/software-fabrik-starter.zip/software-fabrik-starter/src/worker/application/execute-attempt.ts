import type { Task } from '../../shared/contracts.js';
import type { Snapshot } from '../../shared/snapshots.js';
import type { AttemptDependencies } from './ports.js';
import { AttemptLease } from './lease.js';
import { reportWithRetry } from './reporting.js';

/** Runs one assigned attempt. A durable terminal snapshot is the execution replay boundary. */
export async function executeAttempt(task: Task, stop: AbortSignal, dependencies: AttemptDependencies): Promise<void> {
  const { client, journal, adapter, identity, profiles, state, saveState, timeoutMs } = dependencies;
  const now = dependencies.now ?? Date.now;
  const profile = profiles.find(candidate => candidate.id === task.profile);
  if (!profile || task.workerId !== identity.id || task.project !== identity.project || !task.lease) {
    throw Error('Invalid task assignment');
  }
  if (adapter.mode !== 'mock') throw Error('Only mock execution is supported by this worker');
  const lease = new AttemptLease(task, client, state, now);
  const flush = () => journal.flush(snapshot => client.publishSnapshot(snapshot));

  try {
    await lease.start();
    let after = await journal.read(task.lease, 'after');
    if (!after) {
      const before = await journal.persist(journal.capture(task, identity.id, profile, state, 'before'));
      state.lastSnapshot = before.id;
      await saveState();
      const signal = AbortSignal.any([stop, lease.signal, AbortSignal.timeout(timeoutMs)]);
      let outcome: Snapshot['execution']['outcome'] = 'failed';
      let error: string | null = null;
      try {
        await reportWithRetry(flush, signal);
        signal.throwIfAborted();
        const result = await adapter.run(task, signal);
        signal.throwIfAborted();
        if (result.kind !== 'simulated') throw Error('Mock adapter returned an unsupported change-set');
        outcome = 'simulated';
      } catch (cause) {
        outcome = stop.aborted || lease.signal.aborted ? 'interrupted' : 'failed';
        error = signal.aborted ? 'Execution interrupted or timed out' : (cause as Error).message;
      }
      after = await journal.persist(journal.capture(task, identity.id, profile, state, 'after', before, outcome, error));
    }
    state.lastSnapshot = after.id;
    // Lease ownership extends through telemetry publication and terminal acknowledgment.
    await reportWithRetry(flush, stop);
    lease.signal.throwIfAborted();
    if (after.execution.outcome === 'simulated') {
      await reportWithRetry(() => client.complete(task), stop);
      state.completedSimulations++;
    } else {
      await reportWithRetry(() => client.abandon(task), stop);
    }
    state.lastContact = new Date(now()).toISOString();
  } finally {
    await lease.close();
  }
}
