import type { Adapter, Profile, Task, WorkerPolicy } from '../../shared/contracts.js';
import type { Snapshot } from '../../shared/snapshots.js';

export interface WorkerIdentity {
  id: string;
  token: string;
  project: string;
  url: string;
  configHash: string;
}

/** The worker application knows operations, never URLs or bearer tokens. */
export interface WorkerClient {
  currentAssignments(): Promise<Task[]>;
  claim(requestId: string): Promise<Task | null>;
  heartbeat(task: Task): Promise<Task>;
  publishSnapshot(snapshot: Snapshot): Promise<void>;
  complete(task: Task): Promise<void>;
  abandon(task: Task): Promise<void>;
}

export interface WorkerGateway {
  register(profiles: Profile[], policy: WorkerPolicy): Promise<Pick<WorkerIdentity, 'id' | 'token' | 'project'>>;
  connect(identity: WorkerIdentity): WorkerClient;
}

export interface SnapshotStatus {
  lastContact: string | null;
  heartbeatErrors: number;
}

export interface AttemptState extends SnapshotStatus {
  lastError: string | null;
  lastSnapshot: string | null;
  completedSimulations: number;
}

export interface AttemptJournal {
  read(pairId: string, phase: string): Promise<Snapshot | null>;
  persist(snapshot: Snapshot): Promise<Snapshot>;
  capture(task: Task, workerId: string, profile: Profile, state: SnapshotStatus,
    phase: 'before' | 'after', before?: Snapshot, outcome?: Snapshot['execution']['outcome'],
    error?: string | null): Snapshot;
  flush(send: (snapshot: Snapshot) => Promise<unknown>): Promise<void>;
}

export interface AttemptDependencies {
  client: WorkerClient;
  journal: AttemptJournal;
  adapter: Adapter;
  identity: Pick<WorkerIdentity, 'id' | 'project'>;
  profiles: Profile[];
  state: AttemptState;
  saveState(): Promise<void>;
  timeoutMs: number;
  /** Wall clock is used only for server lease expiry and human-readable contact time. */
  now?: () => number;
}
